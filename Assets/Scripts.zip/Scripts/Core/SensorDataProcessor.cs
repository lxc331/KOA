using System;
using UnityEngine;

/// <summary>
/// 四传感器下肢数据处理器。
/// 06/07 驱动左腿，08/09 驱动右腿；01~05 始终保持绑定姿态。
/// 稳定性只在收到真实串口帧时累计，腿部只消费同侧、时间配对后的数据。
/// </summary>
public class SensorDataProcessor
{
    private const int LeftThighIndex = 5;
    private const int LeftCalfIndex = 6;
    private const int RightThighIndex = 7;
    private const int RightCalfIndex = 8;
    private const int FirstLowerBodyIndex = LeftThighIndex;

    private readonly int deviceCount;
    private readonly MotionCaptureConfig config;
    private readonly Quaternion[] rawQuaternions;
    private readonly Quaternion[] transformedQuaternions;
    private readonly float[] yaw;
    private readonly float[] pitch;
    private readonly float[] roll;

    // 稳定性必须按真实输入帧和真实时间计算，不能按 Unity Update 帧累计。
    private readonly Quaternion[] stabilityPreviousQuaternions;
    private readonly DateTime[] stabilityPreviousTimestamps;
    private readonly DateTime[] latestAcceptedTimestamps;
    private readonly float[] stableDurationsSeconds;
    private readonly int[] stableCounts;
    private readonly bool[] stabilityInitialized;
    private readonly bool[] deviceStable;

    private readonly Quaternion[] leftLegDriveInput;
    private readonly Quaternion[] rightLegDriveInput;
    private Quaternion[] restLocalRotations;

    private readonly LeftLegPoseDriver leftLegDriver;
    private readonly RightLegPoseDriver rightLegDriver;

    private bool leftThighFresh;
    private bool rightThighFresh;
    private bool leftPairAvailable;
    private bool rightPairAvailable;

    private Quaternion rootFacingOffset = Quaternion.identity;

    /// <summary>
    /// 保留通用驱动器供现有 UI 开关和旧调用兼容；下肢骨骼不再由它写入。
    /// </summary>
    public RotationDriver Driver { get; private set; }

    public LeftLegPoseDriver LeftLegDriver => leftLegDriver;
    public RightLegPoseDriver RightLegDriver => rightLegDriver;
    public Quaternion[] TransformedQuaternions => transformedQuaternions;
    public Quaternion[] RawQuaternions => rawQuaternions;
    public int[] StableCounts => stableCounts;
    public bool IsCalibrated => leftLegDriver.IsCalibrated && rightLegDriver.IsCalibrated;

    public int LastSyncLatestCount { get; private set; }
    public int LastSyncDevicesApplied { get; private set; }
    public float LastSyncSkewMilliseconds { get; private set; } = -1f;
    public string LastSyncStatus { get; private set; } = "not_started";

    public float LastLeftPairSkewMilliseconds { get; private set; } = -1f;
    public float LastRightPairSkewMilliseconds { get; private set; } = -1f;
    public float LastLeftPairAgeMilliseconds { get; private set; } = -1f;
    public float LastRightPairAgeMilliseconds { get; private set; } = -1f;
    public string LastLeftPairStatus { get; private set; } = "not_started";
    public string LastRightPairStatus { get; private set; } = "not_started";
    public long LeftPairHoldCount { get; private set; }
    public long RightPairHoldCount { get; private set; }

    public SensorDataProcessor(MotionCaptureConfig config)
    {
        this.config = config;
        deviceCount = config.deviceCount;

        rawQuaternions = new Quaternion[deviceCount];
        transformedQuaternions = new Quaternion[deviceCount];
        yaw = new float[deviceCount];
        pitch = new float[deviceCount];
        roll = new float[deviceCount];
        stabilityPreviousQuaternions = new Quaternion[deviceCount];
        stabilityPreviousTimestamps = new DateTime[deviceCount];
        latestAcceptedTimestamps = new DateTime[deviceCount];
        stableDurationsSeconds = new float[deviceCount];
        stableCounts = new int[deviceCount];
        stabilityInitialized = new bool[deviceCount];
        deviceStable = new bool[deviceCount];
        leftLegDriveInput = new Quaternion[deviceCount];
        rightLegDriveInput = new Quaternion[deviceCount];

        for (int i = 0; i < deviceCount; i++)
        {
            rawQuaternions[i] = Quaternion.identity;
            transformedQuaternions[i] = Quaternion.identity;
            stabilityPreviousQuaternions[i] = Quaternion.identity;
            leftLegDriveInput[i] = Quaternion.identity;
            rightLegDriveInput[i] = Quaternion.identity;
        }

        Driver = new RotationDriver(
            deviceCount, true, config.smoothSpeed, config.debounceThresholdDeg, false);

        // V8.22 已验证的左腿基线。
        leftLegDriver = new LeftLegPoseDriver
        {
            DriveCalf = true,
            InputLowPassEnabled = false,
            SmoothingEnabled = true,
            SmoothingSpeed = config.legOutputSmoothingSpeed,
            MaximumAngularSpeedDegPerSec = config.legMaximumAngularSpeedDegPerSec,
            ThighAxisInvertMode = LeftThighAxisInvertMode.InvertY,
            LimitThighTwist = true,
            ThighTwistAxisMode = LeftThighTwistAxisMode.LocalY,
            MaxThighTwistDeg = 0f,
            ThighApplyOrder = LeftThighApplyOrder.RestThenDelta,
            MinBoneAngleThresholdDeg = 0f,
            StaticCheckLogEnabled = false,
            KneeDebugLogEnabled = false
        };

        // “新右腿算法 + V8.22 通信层”基线。右小腿关闭额外侧摆，只保留膝铰链，
        // 避免 09 的非铰链漂移直接把脚部拧向侧面。
        rightLegDriver = new RightLegPoseDriver
        {
            DriveCalf = true,
            InvertThighLateralDirection = false,
            SuppressSagittalLateralCrossTalk = false,
            InputLowPassEnabled = false,
            SmoothingEnabled = true,
            SmoothingSpeed = config.legOutputSmoothingSpeed,
            MaximumAngularSpeedDegPerSec = config.legMaximumAngularSpeedDegPerSec,
            ThighAxisInvertMode = RightThighAxisInvertMode.InvertY,
            ThighEulerRemapMode = RightThighEulerRemapMode.SwapYZ,
            LimitThighTwist = false,
            ThighTwistAxisMode = RightThighTwistAxisMode.LocalY,
            MaxThighTwistDeg = 0f,
            ThighApplyOrder = RightThighApplyOrder.RestThenDelta,
            EnableCalfLateralSwing = false,
            MinBoneAngleThresholdDeg = 0f,
            StaticCheckLogEnabled = false,
            KneeDebugLogEnabled = false
        };
    }

    public void SetRootFacingOffset(Quaternion offset)
    {
        rootFacingOffset = NormalizeSafe(offset);
    }

    public void InitConstraints(Quaternion[] restRotations)
    {
        restLocalRotations = restRotations != null
            ? (Quaternion[])restRotations.Clone()
            : null;
        Driver.SetConstraints(config.minLocalAngles, config.maxLocalAngles, restRotations);
    }

    public void SetSmoothing(bool enabled, float speed)
    {
        Driver.SetSmoothing(enabled, speed);
        float safeSpeed = Mathf.Max(0.01f, speed);
        leftLegDriver.SmoothingEnabled = enabled;
        leftLegDriver.SmoothingSpeed = safeSpeed;
        rightLegDriver.SmoothingEnabled = enabled;
        rightLegDriver.SmoothingSpeed = safeSpeed;
    }

    /// <summary>从解析队列取出所有真实新帧，并在这里更新稳定性。</summary>
    public int DequeueAll(
        SerialParser parser,
        MotionCaptureState state,
        Action<int, Quaternion, Vector3> onFrame)
    {
        if (parser == null || state == null) return 0;

        int count = 0;
        while (parser.TryDequeue(out int deviceId, out Quaternion q))
        {
            if (deviceId < 0 || deviceId >= deviceCount) continue;

            q = NormalizeSafe(q);
            rawQuaternions[deviceId] = q;

            Vector3 e = q.eulerAngles;
            yaw[deviceId] = e.z;
            pitch[deviceId] = e.y;
            roll[deviceId] = e.x;

            DateTime timestamp = DateTime.Now;
            if (parser.TryGetLatestFrame(deviceId, out SerialParser.SensorFrame latest))
                timestamp = latest.Timestamp;

            latestAcceptedTimestamps[deviceId] = timestamp;
            Quaternion mapped = MapSensorToAvatarSpace(deviceId, q);
            UpdateStabilityFromRealFrame(deviceId, mapped, timestamp);

            state.SetDeviceHasData(deviceId, true);
            state.NotifyEulerUpdated(
                deviceId, new Vector3(roll[deviceId], pitch[deviceId], yaw[deviceId]));
            onFrame?.Invoke(deviceId, q, e);
            count++;
        }

        return count;
    }

    public void TransformAll(MotionCaptureState state)
    {
        if (state == null) return;
        for (int i = 0; i < deviceCount; i++)
        {
            if (!state.GetDeviceHasData(i))
            {
                transformedQuaternions[i] = Quaternion.identity;
                continue;
            }

            transformedQuaternions[i] = MapSensorToAvatarSpace(i, rawQuaternions[i]);
            state.SetDeviceQuaternion(i, transformedQuaternions[i]);
        }
    }

    /// <summary>
    /// 稳定性已在真实帧回调中更新；这里仅让陈旧设备退出稳定状态。
    /// </summary>
    public void UpdateStability(MotionCaptureState state)
    {
        if (state == null) return;
        for (int i = FirstLowerBodyIndex; i <= RightCalfIndex && i < deviceCount; i++)
        {
            if (!state.GetDeviceHasData(i) ||
                !IsDeviceFresh(i, config.calibrationFreshnessTimeoutSeconds))
            {
                deviceStable[i] = false;
                stableCounts[i] = 0;
                stableDurationsSeconds[i] = 0f;
                stabilityInitialized[i] = false;
            }
        }
    }

    /// <summary>四传感器模式固定要求 06~09 全部存在、在线且稳定。</summary>
    public bool CheckStability(GameObject[] bones, bool[] deviceHasData)
    {
        if (deviceCount <= RightCalfIndex || bones == null || deviceHasData == null)
            return false;

        for (int i = FirstLowerBodyIndex; i <= RightCalfIndex; i++)
        {
            if (i >= bones.Length || bones[i] == null ||
                i >= deviceHasData.Length || !deviceHasData[i] ||
                !IsDeviceFresh(i, config.calibrationFreshnessTimeoutSeconds) ||
                !deviceStable[i])
                return false;
        }

        return true;
    }

    /// <summary>
    /// 只在四路均稳定且两条腿都取得新鲜配对数据时完成标定。
    /// </summary>
    public bool TryPreCalibrate(
        SerialParser parser,
        GameObject[] bones,
        Quaternion[] restRotations,
        out string reason)
    {
        reason = string.Empty;
        if (IsCalibrated) return true;
        if (!ValidateLowerBodyBones(bones, restRotations, out reason)) return false;

        for (int i = FirstLowerBodyIndex; i <= RightCalfIndex; i++)
        {
            if (!deviceStable[i] ||
                !IsDeviceFresh(i, config.calibrationFreshnessTimeoutSeconds))
            {
                reason = $"{i + 1:00}号传感器尚未稳定或数据已陈旧";
                return false;
            }
        }

        bool leftPaired = TryPrepareLegPair(
            parser, true, false, leftLegDriveInput,
            out PairResult leftPair);
        bool rightPaired = TryPrepareLegPair(
            parser, false, false, rightLegDriveInput,
            out PairResult rightPair);
        PublishPairResult(true, leftPair, leftPaired, false);
        PublishPairResult(false, rightPair, rightPaired, false);

        if (!leftPaired || !rightPaired)
        {
            reason = !leftPaired
                ? $"左腿06/07无法完成时间配对：{leftPair.Status}"
                : $"右腿08/09无法完成时间配对：{rightPair.Status}";
            return false;
        }

        bool leftOk = leftLegDriver.TryCalibrate(
            leftLegDriveInput,
            bones[LeftThighIndex].transform,
            bones[LeftCalfIndex].transform,
            restRotations[LeftThighIndex],
            restRotations[LeftCalfIndex],
            out string leftReason);

        bool rightOk = rightLegDriver.TryCalibrate(
            rightLegDriveInput,
            bones[RightThighIndex].transform,
            bones[RightCalfIndex].transform,
            restRotations[RightThighIndex],
            restRotations[RightCalfIndex],
            out string rightReason);

        if (!leftOk || !rightOk)
        {
            leftLegDriver.Reset();
            rightLegDriver.Reset();
            reason = !leftOk ? $"左腿标定失败：{leftReason}" : $"右腿标定失败：{rightReason}";
            return false;
        }

        leftLegDriver.TryCalibrateKneeMeasurement(
            leftPair.Thigh, leftPair.Calf,
            bones[LeftThighIndex].transform,
            bones[LeftCalfIndex].transform,
            out _);
        rightLegDriver.TryCalibrateKneeMeasurement(
            rightPair.Thigh, rightPair.Calf,
            bones[RightThighIndex].transform,
            bones[RightCalfIndex].transform,
            out _);

        // 仅用于兼容旧 UI/日志读取；下肢姿态不会再由该通用驱动器应用。
        Driver.Calibrate(bones, transformedQuaternions);
        reason = "06~09四传感器稳定标定完成";
        return true;
    }

    /// <summary>
    /// 为两条腿分别建立时间配对输入。配对失败时大腿仍可用自身新鲜数据，
    /// 小腿保持最后可信姿势，绝不把两个相差数秒的姿态拼在一起。
    /// </summary>
    public void SyncAndUpdateTargets(
        SerialParser parser,
        MotionCaptureState state,
        GameObject[] bones,
        bool requireAllDevices)
    {
        LastSyncLatestCount = 0;
        LastSyncDevicesApplied = 0;
        LastSyncSkewMilliseconds = -1f;

        for (int i = FirstLowerBodyIndex; i <= RightCalfIndex && i < deviceCount; i++)
        {
            if (parser != null && parser.TryGetLatestFrame(i, out _))
                LastSyncLatestCount++;
        }

        leftThighFresh = IsDeviceFresh(LeftThighIndex, config.runtimeFreshnessTimeoutSeconds);
        rightThighFresh = IsDeviceFresh(RightThighIndex, config.runtimeFreshnessTimeoutSeconds);

        leftPairAvailable = TryPrepareLegPair(
            parser, true, true, leftLegDriveInput,
            out PairResult leftPair);
        rightPairAvailable = TryPrepareLegPair(
            parser, false, true, rightLegDriveInput,
            out PairResult rightPair);

        PublishPairResult(true, leftPair, leftPairAvailable, true);
        PublishPairResult(false, rightPair, rightPairAvailable, true);

        if (leftThighFresh) LastSyncDevicesApplied++;
        if (leftPairAvailable) LastSyncDevicesApplied++;
        if (rightThighFresh) LastSyncDevicesApplied++;
        if (rightPairAvailable) LastSyncDevicesApplied++;

        float maxSkew = Mathf.Max(
            LastLeftPairSkewMilliseconds,
            LastRightPairSkewMilliseconds);
        LastSyncSkewMilliseconds = maxSkew >= 0f ? maxSkew : -1f;
        LastSyncStatus = $"left={LastLeftPairStatus};right={LastRightPairStatus}";

        if (leftPairAvailable)
        {
            leftLegDriver.UpdateKneeMeasurement(
                leftPair.Thigh, leftPair.Calf, leftPair.Timestamp,
                leftPair.RawSkewSeconds, leftPair.AgeSeconds,
                config.runtimeFreshnessTimeoutSeconds);
        }
        else
        {
            leftLegDriver.MarkKneeMeasurementStale(leftPair.AgeSeconds);
        }

        if (rightPairAvailable)
        {
            rightLegDriver.UpdateKneeMeasurement(
                rightPair.Thigh, rightPair.Calf, rightPair.Timestamp,
                rightPair.RawSkewSeconds, rightPair.AgeSeconds,
                config.runtimeFreshnessTimeoutSeconds);
        }
        else
        {
            rightLegDriver.MarkKneeMeasurementStale(rightPair.AgeSeconds);
        }
    }

    /// <summary>在 LateUpdate 写骨骼。上半身固定，左右腿由独立驱动器写入。</summary>
    public void ApplyToBones(GameObject[] bones)
    {
        if (!IsCalibrated || bones == null) return;

        // 只传 06~09 的版本必须明确保持上半身绑定姿态不动。
        if (restLocalRotations != null)
        {
            int upperCount = Mathf.Min(FirstLowerBodyIndex, Mathf.Min(bones.Length, restLocalRotations.Length));
            for (int i = 0; i < upperCount; i++)
            {
                if (bones[i] != null)
                    bones[i].transform.localRotation = restLocalRotations[i];
            }
        }

        Transform leftThigh = GetBoneTransform(bones, LeftThighIndex);
        Transform leftCalf = GetBoneTransform(bones, LeftCalfIndex);
        Transform rightThigh = GetBoneTransform(bones, RightThighIndex);
        Transform rightCalf = GetBoneTransform(bones, RightCalfIndex);

        if (leftThighFresh)
        {
            leftLegDriver.ApplyAvailable(
                leftLegDriveInput, leftThigh, leftCalf,
                true, leftPairAvailable);
        }
        else
        {
            HoldLastLegPose(
                leftThigh, leftCalf,
                leftLegDriver.LastAppliedThighLocal,
                leftLegDriver.LastAppliedCalfLocal);
        }

        if (rightThighFresh)
        {
            rightLegDriver.ApplyAvailable(
                rightLegDriveInput, rightThigh, rightCalf,
                true, rightPairAvailable);
        }
        else
        {
            HoldLastLegPose(
                rightThigh, rightCalf,
                rightLegDriver.LastAppliedThighLocal,
                rightLegDriver.LastAppliedCalfLocal);
        }
    }

    public bool TryGetDiagnosticTarget(int index, out Quaternion target)
    {
        target = Quaternion.identity;
        if (!IsCalibrated) return false;

        switch (index)
        {
            case LeftThighIndex:
                target = leftLegDriver.LastThighTargetLocal;
                return true;
            case LeftCalfIndex:
                target = leftLegDriver.LastCalfTargetLocal;
                return true;
            case RightThighIndex:
                target = rightLegDriver.LastThighTargetLocal;
                return true;
            case RightCalfIndex:
                target = rightLegDriver.LastCalfTargetLocal;
                return true;
            default:
                if (restLocalRotations != null && index >= 0 && index < restLocalRotations.Length)
                {
                    target = restLocalRotations[index];
                    return true;
                }
                return false;
        }
    }

    public float GetDeviceAgeMilliseconds(int deviceId)
    {
        double seconds = GetDeviceAgeSeconds(deviceId);
        return double.IsInfinity(seconds) ? -1f : (float)(seconds * 1000d);
    }

    public bool IsDeviceStable(int deviceId)
    {
        return deviceId >= 0 && deviceId < deviceCount && deviceStable[deviceId];
    }

    public void Reset(GameObject[] bones, Quaternion[] restRotations)
    {
        for (int i = 0; i < deviceCount; i++)
        {
            rawQuaternions[i] = Quaternion.identity;
            transformedQuaternions[i] = Quaternion.identity;
            stabilityPreviousQuaternions[i] = Quaternion.identity;
            stabilityPreviousTimestamps[i] = DateTime.MinValue;
            latestAcceptedTimestamps[i] = DateTime.MinValue;
            stableDurationsSeconds[i] = 0f;
            stableCounts[i] = 0;
            stabilityInitialized[i] = false;
            deviceStable[i] = false;
            leftLegDriveInput[i] = Quaternion.identity;
            rightLegDriveInput[i] = Quaternion.identity;
        }

        Driver.ResetToRestPose(bones, restRotations);
        leftLegDriver.Reset();
        rightLegDriver.Reset();
        restLocalRotations = restRotations != null
            ? (Quaternion[])restRotations.Clone()
            : null;

        leftThighFresh = false;
        rightThighFresh = false;
        leftPairAvailable = false;
        rightPairAvailable = false;
        LastSyncLatestCount = 0;
        LastSyncDevicesApplied = 0;
        LastSyncSkewMilliseconds = -1f;
        LastSyncStatus = "reset";
        LastLeftPairStatus = "reset";
        LastRightPairStatus = "reset";
        LastLeftPairSkewMilliseconds = -1f;
        LastRightPairSkewMilliseconds = -1f;
        LastLeftPairAgeMilliseconds = -1f;
        LastRightPairAgeMilliseconds = -1f;
        LeftPairHoldCount = 0;
        RightPairHoldCount = 0;
    }

    public void ResetStabilityMonitor()
    {
        for (int i = 0; i < deviceCount; i++)
        {
            stabilityPreviousQuaternions[i] = Quaternion.identity;
            stabilityPreviousTimestamps[i] = DateTime.MinValue;
            stableDurationsSeconds[i] = 0f;
            stableCounts[i] = 0;
            stabilityInitialized[i] = false;
            deviceStable[i] = false;
        }
    }

    private void UpdateStabilityFromRealFrame(int deviceId, Quaternion q, DateTime timestamp)
    {
        if (deviceId < 0 || deviceId >= deviceCount) return;

        if (!stabilityInitialized[deviceId])
        {
            stabilityInitialized[deviceId] = true;
            stabilityPreviousQuaternions[deviceId] = q;
            stabilityPreviousTimestamps[deviceId] = timestamp;
            stableDurationsSeconds[deviceId] = 0f;
            stableCounts[deviceId] = 0;
            deviceStable[deviceId] = false;
            return;
        }

        double dt = (timestamp - stabilityPreviousTimestamps[deviceId]).TotalSeconds;
        if (dt <= 0.0001d)
        {
            // 同一 Unity 帧清空积压队列时可能读到相同时间戳；不重复累计稳定时间。
            stabilityPreviousQuaternions[deviceId] = q;
            return;
        }

        float angularSpeed = Quaternion.Angle(stabilityPreviousQuaternions[deviceId], q) / (float)dt;
        float stableThreshold = Mathf.Max(0.1f, config.stableAngularSpeedDegPerSec);
        float unstableThreshold = Mathf.Max(stableThreshold, config.unstableAngularSpeedDegPerSec);

        if (angularSpeed <= stableThreshold)
        {
            stableDurationsSeconds[deviceId] += (float)dt;
        }
        else if (angularSpeed >= unstableThreshold)
        {
            stableDurationsSeconds[deviceId] = 0f;
            deviceStable[deviceId] = false;
        }

        float requiredDuration = Mathf.Max(0.05f, config.requiredStableDurationSeconds);
        deviceStable[deviceId] = stableDurationsSeconds[deviceId] >= requiredDuration;
        stableCounts[deviceId] = Mathf.Clamp(
            Mathf.FloorToInt(
                stableDurationsSeconds[deviceId] / requiredDuration *
                Mathf.Max(1, config.requiredStableFrames)),
            0,
            Mathf.Max(1, config.requiredStableFrames));

        stabilityPreviousQuaternions[deviceId] = q;
        stabilityPreviousTimestamps[deviceId] = timestamp;
    }

    private bool TryPrepareLegPair(
        SerialParser parser,
        bool leftSide,
        bool useCurrentThigh,
        Quaternion[] output,
        out PairResult result)
    {
        result = PairResult.Failed("parser_unavailable");
        if (parser == null || output == null || output.Length < deviceCount)
            return false;

        int thighIndex = leftSide ? LeftThighIndex : RightThighIndex;
        int calfIndex = leftSide ? LeftCalfIndex : RightCalfIndex;
        Array.Copy(transformedQuaternions, output, deviceCount);

        if (!parser.TryGetLatestFrame(thighIndex, out SerialParser.SensorFrame thighLatest))
        {
            result = PairResult.Failed("thigh_missing");
            return false;
        }
        if (!parser.TryGetLatestFrame(calfIndex, out SerialParser.SensorFrame calfLatest))
        {
            result = PairResult.Failed("calf_missing");
            return false;
        }

        double thighAge = GetAgeSeconds(thighLatest.Timestamp);
        double calfAge = GetAgeSeconds(calfLatest.Timestamp);
        double maxAge = useCurrentThigh
            ? config.runtimeFreshnessTimeoutSeconds
            : config.calibrationFreshnessTimeoutSeconds;
        if (thighAge > maxAge)
        {
            result = PairResult.Failed("thigh_stale", thighAge);
            return false;
        }
        if (calfAge > maxAge)
        {
            result = PairResult.Failed("calf_stale", calfAge);
            return false;
        }

        SerialParser.SensorFrame thighPair = thighLatest;
        SerialParser.SensorFrame calfPair = calfLatest;
        DateTime pairTime = thighLatest.Timestamp <= calfLatest.Timestamp
            ? thighLatest.Timestamp
            : calfLatest.Timestamp;
        double rawSkew = Math.Abs((thighLatest.Timestamp - calfLatest.Timestamp).TotalSeconds);
        bool interpolated = false;

        if (thighLatest.Timestamp > pairTime &&
            parser.TryGetInterpolatedFrame(thighIndex, pairTime, out SerialParser.SensorFrame thighInterpolated))
        {
            thighPair = thighInterpolated;
            interpolated = true;
        }
        if (calfLatest.Timestamp > pairTime &&
            parser.TryGetInterpolatedFrame(calfIndex, pairTime, out SerialParser.SensorFrame calfInterpolated))
        {
            calfPair = calfInterpolated;
            interpolated = true;
        }

        // 若无法插值到同一时刻，只允许有限的原始到达时间差。
        if (!interpolated && rawSkew > config.legPairMaxSkewSeconds)
        {
            result = PairResult.Failed("pair_skew_exceeded", Math.Max(thighAge, calfAge), rawSkew);
            return false;
        }

        Quaternion pairedThigh = MapSensorToAvatarSpace(thighIndex, thighPair.Q);
        Quaternion pairedCalf = MapSensorToAvatarSpace(calfIndex, calfPair.Q);
        Quaternion driveThigh = useCurrentThigh
            ? transformedQuaternions[thighIndex]
            : pairedThigh;
        Quaternion driveCalf = useCurrentThigh
            ? ComposeTimePairedCalfForCurrentThigh(driveThigh, pairedThigh, pairedCalf)
            : pairedCalf;

        output[thighIndex] = driveThigh;
        output[calfIndex] = driveCalf;
        result = new PairResult
        {
            Success = true,
            Status = interpolated ? "paired_interpolated" : "paired_within_skew",
            Thigh = pairedThigh,
            Calf = pairedCalf,
            Timestamp = pairTime,
            RawSkewSeconds = rawSkew,
            AgeSeconds = GetAgeSeconds(pairTime)
        };
        return true;
    }

    public static Quaternion ComposeTimePairedCalfForCurrentThigh(
        Quaternion currentThigh,
        Quaternion pairedThigh,
        Quaternion pairedCalf)
    {
        currentThigh = NormalizeSafe(currentThigh);
        pairedThigh = NormalizeSafe(pairedThigh);
        pairedCalf = NormalizeSafe(pairedCalf);
        Quaternion relative = NormalizeSafe(Quaternion.Inverse(pairedThigh) * pairedCalf);
        return NormalizeSafe(currentThigh * relative);
    }

    private void PublishPairResult(bool leftSide, PairResult result, bool success, bool countHold)
    {
        float skewMs = double.IsInfinity(result.RawSkewSeconds)
            ? -1f
            : (float)(result.RawSkewSeconds * 1000d);
        float ageMs = double.IsInfinity(result.AgeSeconds)
            ? -1f
            : (float)(result.AgeSeconds * 1000d);

        if (leftSide)
        {
            LastLeftPairStatus = result.Status;
            LastLeftPairSkewMilliseconds = skewMs;
            LastLeftPairAgeMilliseconds = ageMs;
            if (!success && countHold) LeftPairHoldCount++;
        }
        else
        {
            LastRightPairStatus = result.Status;
            LastRightPairSkewMilliseconds = skewMs;
            LastRightPairAgeMilliseconds = ageMs;
            if (!success && countHold) RightPairHoldCount++;
        }
    }

    private bool ValidateLowerBodyBones(
        GameObject[] bones,
        Quaternion[] restRotations,
        out string reason)
    {
        reason = string.Empty;
        if (deviceCount <= RightCalfIndex || bones == null || bones.Length <= RightCalfIndex ||
            restRotations == null || restRotations.Length <= RightCalfIndex)
        {
            reason = "四传感器骨骼或绑定姿态数组长度不足";
            return false;
        }

        for (int i = FirstLowerBodyIndex; i <= RightCalfIndex; i++)
        {
            if (bones[i] == null)
            {
                reason = $"未找到{i + 1:00}号对应骨骼";
                return false;
            }
        }

        return true;
    }

    private bool IsDeviceFresh(int deviceId, double maxAgeSeconds)
    {
        return GetDeviceAgeSeconds(deviceId) <= Math.Max(0.05d, maxAgeSeconds);
    }

    private double GetDeviceAgeSeconds(int deviceId)
    {
        if (deviceId < 0 || deviceId >= deviceCount ||
            latestAcceptedTimestamps[deviceId] == DateTime.MinValue)
            return double.PositiveInfinity;
        return GetAgeSeconds(latestAcceptedTimestamps[deviceId]);
    }

    private static double GetAgeSeconds(DateTime timestamp)
    {
        if (timestamp == DateTime.MinValue) return double.PositiveInfinity;
        return Math.Max(0d, (DateTime.Now - timestamp).TotalSeconds);
    }

    /// <summary>
    /// 绕开当前 Main.dll 中“所有索引误走 LHand”的映射错误。
    /// 06/08 大腿共用 F_ZXY；07/09 使用各自已验证的小腿安装轴。
    /// </summary>
    private Quaternion MapSensorToAvatarSpace(int index, Quaternion rawSensorQ)
    {
        Quaternion q = NormalizeSafe(rawSensorQ);
        Quaternion unityQ;
        if (index >= LeftThighIndex && index <= RightCalfIndex)
        {
            unityQ = MapLowerBodySensorToUnity(index, q);
        }
        else
        {
            unityQ = RotationDriver.MapSensorToUnity(index, q);
        }

        return NormalizeSafe(rootFacingOffset * NormalizeSafe(unityQ));
    }

    /// <summary>
    /// 06~09 的确定性硬件轴映射。公开为纯函数，供编辑器回归测试和离线日志复算使用。
    /// </summary>
    public static Quaternion MapLowerBodySensorToUnity(int index, Quaternion rawSensorQ)
    {
        Quaternion q = NormalizeSafe(rawSensorQ);
        switch (index)
        {
            case LeftThighIndex:
            case RightThighIndex:
                return NormalizeSafe(new Quaternion(-q.z, -q.x, q.y, q.w));
            case LeftCalfIndex:
                return NormalizeSafe(new Quaternion(-q.x, -q.y, -q.z, q.w));
            case RightCalfIndex:
                return NormalizeSafe(new Quaternion(q.x, -q.y, q.z, q.w));
            default:
                throw new ArgumentOutOfRangeException(
                    nameof(index), index, "四传感器映射只接受索引5~8（设备06~09）");
        }
    }

    private static Transform GetBoneTransform(GameObject[] bones, int index)
    {
        return bones != null && index >= 0 && index < bones.Length && bones[index] != null
            ? bones[index].transform
            : null;
    }

    private static void HoldLastLegPose(
        Transform thigh,
        Transform calf,
        Quaternion thighLocal,
        Quaternion calfLocal)
    {
        if (thigh != null) thigh.localRotation = NormalizeSafe(thighLocal);
        if (calf != null) calf.localRotation = NormalizeSafe(calfLocal);
    }

    private static Quaternion NormalizeSafe(Quaternion q)
    {
        float sqr = q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w;
        if (float.IsNaN(sqr) || float.IsInfinity(sqr) || sqr < 1e-12f)
            return Quaternion.identity;
        float inv = 1f / Mathf.Sqrt(sqr);
        return new Quaternion(q.x * inv, q.y * inv, q.z * inv, q.w * inv);
    }

    private struct PairResult
    {
        public bool Success;
        public string Status;
        public Quaternion Thigh;
        public Quaternion Calf;
        public DateTime Timestamp;
        public double RawSkewSeconds;
        public double AgeSeconds;

        public static PairResult Failed(
            string status,
            double ageSeconds = double.PositiveInfinity,
            double skewSeconds = double.PositiveInfinity)
        {
            return new PairResult
            {
                Success = false,
                Status = status,
                Thigh = Quaternion.identity,
                Calf = Quaternion.identity,
                Timestamp = DateTime.MinValue,
                RawSkewSeconds = skewSeconds,
                AgeSeconds = ageSeconds
            };
        }
    }
}
